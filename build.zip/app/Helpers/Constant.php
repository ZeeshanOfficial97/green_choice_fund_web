<?php

namespace App\Helpers;



class Constant
{

    public const LOOKUP_GROUP_CODE = [
        'userType' => 1,
        'contactReason' => 2
    ];

}
