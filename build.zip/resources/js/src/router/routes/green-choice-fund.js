export default [
  {
    path: '/categories/',
    name: 'apps-categories',
    component: () => import('@/views/apps/calendar/Calendar.vue'),
  },


]
